package com.example.venta_sneackers.Service;

import com.example.venta_sneackers.dto.ProductoRequestDTO;
import com.example.venta_sneackers.dto.ProductoResponseDTO;
import com.example.venta_sneackers.dto.ProductoResponseDto;
import com.example.venta_sneackers.model.Producto;
import com.example.venta_sneackers.model.Talla;
import com.example.venta_sneackers.model.Modelo;
import com.example.venta_sneackers.repository.ProductoRepository;
import com.example.venta_sneackers.repository.TallaRepository;
import com.example.venta_sneackers.repository.ModeloRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductoService {

    private final ProductoRepository repository;
    private final TallaRepository tallaRepository;
    private final ModeloRepository modeloRepository;

    public List<ProductoResponseDTO> obtenerTodos() {
        return repository.findAll().stream().map(producto ->
            new ProductoResponseDTO(
                producto.getIdProducto(),
                producto.getProNombre(),
                producto.getProDescripcion(),
                producto.getProFechaIngreso(),
                producto.getProPrecio(),
                producto.getStock(),
                producto.getProMarca(),
                producto.getProColor(),
                producto.getProGenero(),
                producto.getProEdad(),
                producto.getTalla().getId(),
                producto.getModelo().getIdModelo()
            )).collect(Collectors.toList());
    }   
}
