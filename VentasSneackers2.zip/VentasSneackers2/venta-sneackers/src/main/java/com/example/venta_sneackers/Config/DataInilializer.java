package com.example.venta_sneackers.Config;

import com.example.venta_sneackers.Service.PedidoService;
import com.example.venta_sneackers.model.Cliente;
import com.example.venta_sneackers.model.Detalle;
import com.example.venta_sneackers.model.Modelo;
import com.example.venta_sneackers.model.Pedido;
import com.example.venta_sneackers.model.Producto;
import com.example.venta_sneackers.model.Talla;
import com.example.venta_sneackers.repository.ClienteRepository;
import com.example.venta_sneackers.repository.DetalleRepository;
import com.example.venta_sneackers.repository.ModeloRepository;
import com.example.venta_sneackers.repository.PedidoRepository;
import com.example.venta_sneackers.repository.ProductoRepository;
import com.example.venta_sneackers.repository.TallaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;



@Slf4j
@Component
@RequiredArgsConstructor

public class DataInilializer implements CommandLineRunner {

 private final ModeloRepository modeloRepository;
    private final TallaRepository tallaRepository;
    private final ProductoRepository productoRepository;
    private final ClienteRepository clienteRepository;
    private final PedidoRepository pedidoRepository;
    private final DetalleRepository detalleRepository;

    @Override
    public void run(String... args) {

        //  GUARDIA PRINCIPAL 
        if (productoRepository.count() > 0) {
            log.info(">>> DataInitializer: la BD ya tiene datos, se omite la carga inicial.");
            return;
        }

        log.info(">>> DataInitializer: BD vacia detectada, insertando datos de prueba...");

        //  MODELOS 
        Modelo airMax = modeloRepository.save(
                new Modelo(null, "Zapatilla deportiva clasica", "Air Max", "verano", 2020, false));
        Modelo superstar = modeloRepository.save(
                new Modelo(null, "Icono del streetwear", "Superstar", "primavera", 2018, false));
        Modelo chuckTaylor = modeloRepository.save(
                new Modelo(null, "Edicion especial coleccionable", "Chuck Taylor", "invierno", 2023, true));
        Modelo ultraBoost = modeloRepository.save(
                new Modelo(null, "Zapatilla de alto rendimiento", "Ultra Boost", "verano", 2021, false));
        Modelo oldSkool = modeloRepository.save(
                new Modelo(null, "Clasico del skate", "Old Skool", "otono", 2019, false));
        Modelo blazer = modeloRepository.save(
                new Modelo(null, "Estilo retro basketball", "Blazer Mid", "primavera", 2022, false));
        Modelo yeezy = modeloRepository.save(
                new Modelo(null, "Colaboracion exclusiva", "Yeezy 350", "invierno", 2022, true));
        Modelo airForce = modeloRepository.save(
                new Modelo(null, "Icono del basketball urbano", "Air Force 1", "verano", 2017, false));

        //  TALLAS EU 
        Talla eu36 = tallaRepository.save(new Talla(null, "36", "EU"));
        Talla eu37 = tallaRepository.save(new Talla(null, "37", "EU"));
        Talla eu38 = tallaRepository.save(new Talla(null, "38", "EU"));
        Talla eu39 = tallaRepository.save(new Talla(null, "39", "EU"));
        Talla eu40 = tallaRepository.save(new Talla(null, "40", "EU"));
        Talla eu41 = tallaRepository.save(new Talla(null, "41", "EU"));
        Talla eu42 = tallaRepository.save(new Talla(null, "42", "EU"));
        Talla eu43 = tallaRepository.save(new Talla(null, "43", "EU"));



        //  PRODUCTOS 
        productoRepository.save(new Producto(null, "Nike Air Max 90", "Clasico deportivo blanco",
                "2024-01-10", new BigDecimal("89.99"), 50, "Nike", "Blanco", "unisex", "adulto", eu40, airMax));
        productoRepository.save(new Producto(null, "Nike Air Max 90 Negro", "Clasico deportivo negro",
                "2024-01-15", new BigDecimal("89.99"), 40, "Nike", "Negro", "masculino", "adulto", eu42, airMax));
        productoRepository.save(new Producto(null, "Nike Air Max 90 Kids", "Clasico deportivo para ninos",
                "2024-01-20", new BigDecimal("65.99"), 25, "Nike", "Azul", "unisex", "nino", eu36, airMax));

        productoRepository.save(new Producto(null, "Adidas Superstar Blanco", "Icono urbano blanco",
                "2024-02-01", new BigDecimal("75.00"), 30, "Adidas", "Blanco", "unisex", "adulto", eu41, superstar));
        productoRepository.save(new Producto(null, "Adidas Superstar Negro", "Icono urbano negro",
                "2024-02-10", new BigDecimal("75.00"), 20, "Adidas", "Negro", "femenino", "adulto", eu38, superstar));

        productoRepository.save(new Producto(null, "Converse Chuck Taylor Rojo", "Edicion limitada roja",
                "2024-03-01", new BigDecimal("120.00"), 10, "Converse", "Rojo", "femenino", "adulto", eu37, chuckTaylor));
        productoRepository.save(new Producto(null, "Converse Chuck Taylor Kids", "Edicion limitada para ninos",
                "2024-03-05", new BigDecimal("85.00"), 15, "Converse", "Verde", "unisex", "nino", eu36, chuckTaylor));

        productoRepository.save(new Producto(null, "Adidas Ultra Boost 22", "Alto rendimiento running",
                "2024-04-01", new BigDecimal("150.00"), 35, "Adidas", "Gris", "masculino", "adulto", eu43, ultraBoost));
        productoRepository.save(new Producto(null, "Adidas Ultra Boost Femenino", "Alto rendimiento mujer",
                "2024-04-10", new BigDecimal("145.00"), 20, "Adidas", "Rosa", "femenino", "adulto", eu38, ultraBoost));

        productoRepository.save(new Producto(null, "Vans Old Skool Negro", "Clasico del skate negro",
                "2024-05-01", new BigDecimal("65.00"), 45, "Vans", "Negro", "unisex", "adulto", eu41, oldSkool));
        productoRepository.save(new Producto(null, "Vans Old Skool Kids", "Clasico del skate para ninos",
                "2024-05-10", new BigDecimal("50.00"), 30, "Vans", "Rojo", "unisex", "nino", eu36, oldSkool));

        productoRepository.save(new Producto(null, "Nike Blazer Mid Blanco", "Retro basketball blanco",
                "2024-06-01", new BigDecimal("95.00"), 25, "Nike", "Blanco", "masculino", "adulto", eu42, blazer));
        productoRepository.save(new Producto(null, "Nike Blazer Mid Mujer", "Retro basketball mujer",
                "2024-06-15", new BigDecimal("90.00"), 20, "Nike", "Beige", "femenino", "adulto", eu39, blazer));

        productoRepository.save(new Producto(null, "Yeezy 350 Zebra", "Edicion limitada zebra",
                "2024-07-01", new BigDecimal("250.00"), 5, "Adidas", "Blanco", "unisex", "adulto", eu41, yeezy));
        productoRepository.save(new Producto(null, "Yeezy 350 Bred", "Edicion limitada bred",
                "2024-07-15", new BigDecimal("280.00"), 3, "Adidas", "Negro", "unisex", "adulto", eu43, yeezy));

        productoRepository.save(new Producto(null, "Nike Air Force 1 Blanco", "Icono basketball blanco",
                "2024-08-01", new BigDecimal("85.00"), 60, "Nike", "Blanco", "unisex", "adulto", eu40, airForce));
        productoRepository.save(new Producto(null, "Nike Air Force 1 Kids", "Icono basketball ninos",
                "2024-08-10", new BigDecimal("60.00"), 40, "Nike", "Blanco", "unisex", "nino", eu36, airForce));

        log.info(">>> DataInitializer: {} modelos, {} tallas y {} productos insertados correctamente.",
                modeloRepository.count(), tallaRepository.count(), productoRepository.count());


        //Clientes

        clienteRepository.save(new Cliente(null, "Juan Perez", "Calle siempre viva 1", "Habilitado"));  
        clienteRepository.save(new Cliente(null, "Maria Gomez", "Avenida central 123", "Habilitado"));
        clienteRepository.save(new Cliente(null, "Carlos Sanchez", "Calle falsa 456", "Inhabilitado"));
        clienteRepository.save(new Cliente(null, "Ana Rodriguez", "Avenida del sol 789  ", "Habilitado"));
        clienteRepository.save(new Cliente(null, "Luis Fernandez", "Calle del viento 321", "Inhabilitado"));
        clienteRepository.save(new Cliente(null, "Sofia Martinez", "Avenida de la luna 654", "Habilitado"));
        clienteRepository.save(new Cliente(null, "Diego Ramirez", "Calle del mar 987", "Habilitado"));
        clienteRepository.save(new Cliente(null, "Laura Torres", "Avenida de las estrellas 159", "Inhabilitado"));
        clienteRepository.save(new Cliente(null, "Jorge Diaz", "Calle del bosque 753", "Habilitado"));                       

        //Pedidos

        // Crear detalles de pedidos
        Detalle detalle1 = detalleRepository.save(new Detalle());
        Detalle detalle2 = detalleRepository.save(new Detalle());
        Detalle detalle3 = detalleRepository.save(new Detalle());
        Detalle detalle4 = detalleRepository.save(new Detalle());
        Detalle detalle5 = detalleRepository.save(new Detalle());
        Detalle detalle6 = detalleRepository.save(new Detalle());
        // Obtener clientes existentes
        Cliente cliente1 = clienteRepository.findById(1L).orElse(null);
        Cliente cliente2 = clienteRepository.findById(2L).orElse(null);
        Cliente cliente3 = clienteRepository.findById(4L).orElse(null);
        Cliente cliente4 = clienteRepository.findById(6L).orElse(null);
        Cliente cliente5 = clienteRepository.findById(7L).orElse(null);
        Cliente cliente6 = clienteRepository.findById(9L).orElse(null);

        // Crear pedidos
       if (cliente1 != null && detalle1 != null) {
            pedidoRepository.save(new Pedido(null, "2024-01-15", new BigDecimal("89.00"), new BigDecimal("5.00"), new BigDecimal("84.00"), detalle1, cliente1));
        }
       if (cliente2 != null && detalle2 != null) {
            pedidoRepository.save(new Pedido(null, "2024-02-20", new BigDecimal("150.00"), new BigDecimal("10.00"), new BigDecimal("140.00"), detalle2, cliente2));
        }
        if (cliente3 != null && detalle3 != null) {
            pedidoRepository.save(new Pedido(null, "2024-03-10", new BigDecimal("120.00"), new BigDecimal("0.00"), new BigDecimal("120.00"), detalle3, cliente3));
        }
        if (cliente4 != null && detalle4 != null) {
            pedidoRepository.save(new Pedido(null, "2024-04-05", new BigDecimal("200.00"), new BigDecimal("15.00"), new BigDecimal("185.00"), detalle4, cliente4));
        }
        if (cliente5 != null && detalle5 != null) {
            pedidoRepository.save(new Pedido(null, "2024-05-12", new BigDecimal("95.00"), new BigDecimal("8.00"), new BigDecimal("87.00"), detalle5, cliente5));
        }
        if (cliente6 != null && detalle6 != null) {
            pedidoRepository.save(new Pedido(null, "2024-06-18", new BigDecimal("175.00"), new BigDecimal("12.00"), new BigDecimal("163.00"), detalle6, cliente6));
        }

        log.info(">>> DataInitializer: {} detalles y {} pedidos insertados correctamente.",
                detalleRepository.count(), pedidoRepository.count());
        }

}
