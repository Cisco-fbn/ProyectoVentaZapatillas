package com.example.venta_sneackers.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductoResponseDTO {

    private Long id;
    private String proNombre;
    private BigDecimal proDescripcion;
    private String proFechaIngreso;
    private BigDecimal proPrecio;
    private Integer stock;
    private String proMarca;
    private String proColor;
    private String proGenero;
    private String proEdad;
    private Long tallaId;
    private Long modeloId;
}

