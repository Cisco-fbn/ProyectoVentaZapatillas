package com.example.venta_sneackers.Service;

import com.example.venta_sneackers.dto.PedidoRequestDTO;
import com.example.venta_sneackers.dto.PedidoResponseDTO;
import com.example.venta_sneackers.model.Pedido;
import com.example.venta_sneackers.model.Cliente;
import com.example.venta_sneackers.model.Detalle;
import com.example.venta_sneackers.repository.PedidoRepository;
import com.example.venta_sneackers.repository.ClienteRepository;
import com.example.venta_sneackers.repository.DetalleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PedidoService {

    private final PedidoRepository repository;
    private final ClienteRepository clienteRepository;
    private final DetalleRepository detalleRepository;

    public List<PedidoResponseDTO> obtenerTodos() {
        return repository.findAll().stream().map(pedido ->
            new PedidoResponseDTO(
                pedido.getIdPedido(),
                pedido.getPedFechaCompra(),
                pedido.getPedSubtotal(),
                pedido.getPedDescuento(),
                pedido.getPedTotal(),
                pedido.getDetalle().getIdDetalle(),
                pedido.getCliente().getIdCliente()
            )).collect(Collectors.toList());
    }

    public Optional<PedidoResponseDTO> obtenerPorId(Long id) {
        return repository.findById(id).map(pedido ->
            new PedidoResponseDTO(
                pedido.getIdPedido(),
                pedido.getPedFechaCompra(),
                pedido.getPedSubtotal(),
                pedido.getPedDescuento(),
                pedido.getPedTotal(),
                pedido.getDetalle().getIdDetalle(),
                pedido.getCliente().getIdCliente()
            ));
    }

    public PedidoResponseDTO guardar(PedidoRequestDTO dto) {
        Detalle detalle = detalleRepository.findById(dto.getDetalleId()).orElseThrow();
        Cliente cliente = clienteRepository.findById(dto.getClienteId()).orElseThrow();

        Pedido pedido = new Pedido();
        pedido.setPedFechaCompra(dto.getPedFechaCompra());
        pedido.setPedSubtotal(dto.getPedSubtotal());
        pedido.setPedDescuento(dto.getPedDescuento());
        pedido.setPedTotal(dto.getPedTotal());
        pedido.setDetalle(detalle);
        pedido.setCliente(cliente);

        Pedido saved = repository.save(pedido);
        return new PedidoResponseDTO(
            saved.getIdPedido(),
            saved.getPedFechaCompra(),
            saved.getPedSubtotal(),
            saved.getPedDescuento(),
            saved.getPedTotal(),
            saved.getDetalle().getIdDetalle(),
            saved.getCliente().getIdCliente()
        );
    }

    public PedidoResponseDTO actualizar(Long id, PedidoRequestDTO dto) {
        Pedido pedido = repository.findById(id).orElseThrow();
        Detalle detalle = detalleRepository.findById(dto.getDetalleId()).orElseThrow();
        Cliente cliente = clienteRepository.findById(dto.getClienteId()).orElseThrow();

        pedido.setPedFechaCompra(dto.getPedFechaCompra());
        pedido.setPedSubtotal(dto.getPedSubtotal());
        pedido.setPedDescuento(dto.getPedDescuento());
        pedido.setPedTotal(dto.getPedTotal());
        pedido.setDetalle(detalle);
        pedido.setCliente(cliente);

        Pedido updated = repository.save(pedido);
        return new PedidoResponseDTO(
            updated.getIdPedido(),
            updated.getPedFechaCompra(),
            updated.getPedSubtotal(),
            updated.getPedDescuento(),
            updated.getPedTotal(),
            updated.getDetalle().getIdDetalle(),
            updated.getCliente().getIdCliente()
        );
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
