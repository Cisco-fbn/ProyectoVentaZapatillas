# Upgrade Plan: venta-sneackers (20260525185455)

- **Generated**: 2026-05-25 18:55:00
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- Java 21.0.10: C:\Program Files\Java\jdk-21.0.10\bin (required by steps 1-3)

**Build Tools**
- Maven Wrapper: 3.9.15 (available at .mvn/wrapper/maven-wrapper.properties)
- System Maven: not available (wrapper will be used)

## Guidelines

- Upgrade Java runtime to the latest LTS version: Java 21.
- Preserve the existing Spring Boot 4.0.6 configuration where it already targets Java 21.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260525185455
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 21 (latest LTS runtime)

## Technology Stack

| Technology/Dependency | Current | Min Compatible | Why Incompatible |
| --------------------- | ------- | -------------- | ---------------- |
| Java | 21 | 21 | User requested latest LTS |
| Spring Boot | 4.0.6 | 4.0.6 | Already compatible with Java 21 |
| Maven Wrapper | 3.9.15 | 3.9.15 | Compatible with Java 21 |
| maven-compiler-plugin | Managed by Spring Boot parent | 3.11.0+ | Managed plugin is compatible with Java 21 |
| Lombok | 1.0+ managed | 1.18.0+ | Compatible with Java 21 |

## Derived Upgrades

- No additional runtime upgrade is required because the project already declares `java.version` as 21.
- The Maven wrapper is already configured to use Maven 3.9.15, which is compatible with Java 21.
- No Spring Boot major migration is required for the runtime upgrade goal.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| pom.xml | java.version | 21 | preserve | 21 | Already targets the desired runtime |
| .mvn/wrapper/maven-wrapper.properties | Maven Wrapper version | 3.9.15 | preserve | 3.9.15 | Suitable for Java 21; wrapper will be used for validation |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| None | N/A | N/A | None | Project already targets Java 21 and requires no source-level migration for the runtime upgrade |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| pom.xml | `<java.version>` | 21 | preserve | Already set to latest LTS |
| .mvn/wrapper/maven-wrapper.properties | distributionUrl | Apache Maven 3.9.15 | preserve | Compatible with Java 21 and the existing Maven wrapper setup |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None | N/A | N/A | No CI/CD changes are required in the repository for the runtime upgrade goal |

### Risks & Warnings

- **Runtime verification only**: The project already targets Java 21 in `pom.xml`; the primary risk is that local tooling might not invoke JDK 21. **Mitigation**: Use the Maven wrapper with the available JDK 21 installation and run the full test suite.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm JDK 21 is available and the Maven wrapper is ready for validation.
  - **Changes to Make**: None to project files; verify environment and toolchain.
  - **Verification**: `./mvnw -v` on Windows PowerShell, JDK 21 path present, wrapper executes.

- Step 2: Setup Baseline
  - **Rationale**: Validate the current project build and tests on the target runtime before declaring the upgrade complete.
  - **Changes to Make**: None to project files; run baseline compile and tests.
  - **Verification**: `./mvnw clean compile test-compile -q && ./mvnw clean test -q` with JDK 21.

- Step 3: Final Validation
  - **Rationale**: Confirm the runtime upgrade goal is already satisfied and the project remains fully functional on Java 21.
  - **Changes to Make**: None; verify again after baseline and finalize the result.
  - **Verification**: `./mvnw clean test -q` with JDK 21 and ensure all tests pass.
